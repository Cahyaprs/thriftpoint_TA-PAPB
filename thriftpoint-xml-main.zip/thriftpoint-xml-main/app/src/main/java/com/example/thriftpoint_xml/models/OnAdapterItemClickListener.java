package com.example.thriftpoint_xml.models;

public interface OnAdapterItemClickListener {
    void onDeleteButtonTapped(Product product);

}
